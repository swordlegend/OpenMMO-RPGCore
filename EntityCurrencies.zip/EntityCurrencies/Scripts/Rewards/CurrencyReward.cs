﻿

using System;
using System.Text;
using UnityEngine;
using OpenMMO;

namespace OpenMMO {
	
	[System.Serializable]
	public partial class CurrencyReward : PropertyReward
	{
		public CurrencyTemplate template;
	}

}