﻿// =======================================================================================
// Wovencore
// by Weaver (Fhiz)
// MIT licensed
//
//
// =======================================================================================

using System;
using System.Text;
using UnityEngine;
using OpenMMO;

namespace OpenMMO {

	// -----------------------------------------------------------------------------------
	[System.Serializable]
	public partial class AutoGenerateCurrency
	{
		public LinearGrowthLong amount;
		public LinearGrowthFloat duration;
	}
	
}

// =======================================================================================