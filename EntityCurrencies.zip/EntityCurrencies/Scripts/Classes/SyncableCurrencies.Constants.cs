﻿
using System;
using System.Text;
using UnityEngine;
using OpenMMO;

namespace OpenMMO {

	public partial class Constants
	{
		
		public const string StatProduction = "PRODUCTION";
		
	}
	
}